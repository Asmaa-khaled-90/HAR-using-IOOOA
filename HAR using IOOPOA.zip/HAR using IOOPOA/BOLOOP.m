clear all;
clear all;
clc;
global A trn vald X_test y_test X_train y_train truedata truelabels;

 X_train=load('X_train.txt');
y_train=load('y_train.txt');
X_test=load('X_test.txt');
y_test=load('y_test.txt');

% Combine the feature matrices
X = [X_train; X_test];

% Combine the labels
Y = [y_train; y_test];

   A=[X Y];
  r=(1:size(A,1));
trn=r(1:7352);
vald=r(7352+1:end);

dim=size(X,2); 
MaxIt=50;          % max number of iterations
nPop=15;          % number of solutions in the population
fobj = 'AccSz';     % fitness function
lb=0;
ub=1;
lb = ones(1, dim) * lb; % Lower boundary for each dimension
ub = ones(1, dim) * ub; % Upper boundary for each dimension
MR=.3;  % from 0.1 to 0.9
optimumSol=zeros(1,dim);
optimumFitness=inf;
%% initialization 
    swarm=init_pop(nPop,ub,lb,dim,2) > 0.5;
     Status=round(rand(nPop,dim).*(3-1)+1);
 tic
     itr=1;   % Loop counter
bestcost = nan(MaxIt, 1);
tic
while itr<=MaxIt
  MeanPos = mean(swarm,1);
 Diff = bsxfun(@minus, swarm, MeanPos);

Div(itr) = mean(sqrt(sum(Diff.^2,2)));    
for i=1:nPop
    
    ObjVal(i,1) =feval(fobj,swarm(i,:));
    
    if ObjVal(i,:)<optimumFitness
        optimumFitness=ObjVal(i,:);
        optimumSol=swarm(i,:);
    end
end

for i=1:nPop
[bestFitness,idx]=min(ObjVal); bestSol=swarm(idx,:);
j=i;
            while i==j
                seed=randperm(nPop); 
                j=seed(1);                  
            end

mutualVector=mean([swarm(i,:);swarm(j,:)]);
            BF1=round(1+rand); BF2=round(1+rand);
            swarmNew1=swarm(i,:)+rand(1,dim).*(bestSol-BF1.*mutualVector); 
           swarmNew2=swarm(j,:)+rand(1,dim).*(bestSol-BF2.*mutualVector);

            swarmNew1=swarmNew1>0.5; 
            swarmNew2=swarmNew2>0.5;
% Evaluate the fitness of the new solution
            fitnessNew1=feval(fobj,swarmNew1);

            fitnessNew2=feval(fobj,swarmNew2);

            % Accept the new solution if the fitness is better
            if fitnessNew1<ObjVal(i,:)
                ObjVal(i,:)=fitnessNew1;
                swarm(i,:)=swarmNew1;
            end
            if fitnessNew2<ObjVal(j,:)
               ObjVal(j,:)=fitnessNew2;
               swarm(j,:)=swarmNew2;
            end

end
        
for k=1:nPop
    
    [~, so] = sort(ObjVal);
   
    
      parent =swarm( so(1),:);
    
    parentCost=ObjVal( so(1));

    parentstatus=Status(so(1),:);
    child=rand(1,dim).*(ub-(lb))+(lb)>0.5;

    for l=1:dim
        l;
        parentFeature=parent(l);
        featureStatus=Status(l);
      
        if featureStatus == 1
            swarm(:,l)=parentFeature;

        swarm(:,l)=max(swarm(:,l),lb(l));
        swarm(:,l)=min(swarm(:,l),ub(l));
         child(1,l)=parentFeature;
          %% protected inheritance
        elseif featureStatus ==2
            child(1,l)=parentFeature;
            
        else
            %% do nothing -> no inheritance
    
        end
    end
    child(:)=max (child(:),lb(:));
        child(:)=min (child(:),ub(:));
        
        child;
    childCost =feval(fobj,child);

    if(childCost < parentCost)
        swarm(k,:)=child;
        ObjVal(k,:)=childCost;
    end

end
for i=1:nPop
 for k=1:dim
     if (rand() <MR)
         rr=round(1 + (3-1) .* rand());
         while  isequal(rr, Status(i,k))
 
                 rr=round(1 + (3-1) .* rand());
         end
 
         Status(i)=rr;
     end
 end
 end
 
    bestcost(itr)=optimumFitness;
     % accc = Acc(optimumSol)
     accc = Acc(optimumSol);
         %%----------------                                                                                   ----------------------------------------------------
         
            
            disp(['Iteration ' num2str(itr) ': Best Cost = ' num2str(bestcost(itr)) ' : best position = ' num2str(optimumSol) 'accuracy =' num2str(accc) ]);
            itr=itr+1;
end
DivNorm = (Div - min(Div)) / (max(Div) - min(Div) + eps);
Exploration = DivNorm * 100;
Exploitation = (1 - DivNorm) * 100;
figure;
plot(Exploration,'b','LineWidth',2);
hold on
plot(Exploitation,'r','LineWidth',2);

xlabel('Iteration')
ylabel('Percentage (%)')
legend('Exploration','Exploitation')
